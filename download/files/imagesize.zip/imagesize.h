#ifndef IMAGESIZE_H
#define IMAGESIZE_H

#include <string>

int isPNG(std::string filename);
int isJPEG(std::string filename);
void GetImageSize(std::string filename, unsigned long int &x, unsigned long int &y);

#endif

