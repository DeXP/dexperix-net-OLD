/*
* C++ imagesize - read the dimensions of an image in PNG and JPEG images
*
* Copyright (C) 2008 Hrabrov Dmitry a.k.a. DeXPeriX
* Web: http://dexperix.net
*
* Originally Perl author: Randy J. Ray
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
* In addition, as a special exception, the copyright holders give
* permission to link the code of portions of this program with the
* OpenSSL library under certain conditions as described in each
* individual source file, and distribute linked combinations
* including the two.
* You must obey the GNU General Public License in all respects
* for all of the code used other than OpenSSL.  If you modify
* file(s) with this exception, you may extend this exception to your
* version of the file(s), but you are not obligated to do so.  If you
* do not wish to do so, delete this exception statement from your
* version.  If you delete this exception statement from all source
* files in the program, then also delete it here.
*/


#include <iostream>
#include <fstream>
#include <string>
#include <math.h>

int isPNG(std::string filename){
	std::fstream fin( filename.c_str(), std::ios::in );
	if( ! fin.is_open() ){
		fin.close();
		return 0;
	} else{
		char r;
		int i;
		fin.seekg(12, std::ios::beg);
		char IHDR[5] = "IHDR";
		int ispng = 1;
		for(i=0; i<4; i++){
			fin.get(r);
			if( r != IHDR[i] ) ispng = 0;
		}
		fin.close();
		return ispng;
	}
}

int isJPEG(std::string filename){
	std::fstream fin( filename.c_str(), std::ios::in );
	if( ! fin.is_open() ){
		fin.close();
		return 0;
	} else{
		int isjpeg = 1;
		int i;
		char r;
		int beg[5] = {-1,-40,-1,-32};
		int spec[6] = {74, 70, 73, 70, 0};
		for(i=0; i<4; i++){
			fin.get(r);
			if( int(r) != beg[i] ) isjpeg=0;
		}
		fin.seekg(6, std::ios::beg);
		for(i=0; i<5; i++){
			fin.get(r);
			if( int(r) != spec[i] ) isjpeg=0;
		}
		fin.close();
		return isjpeg;
	}
}

int getval(char r){
	int tmp = int(r);
	if( tmp < 0 ) tmp += 256;
	return tmp;
}

unsigned long int getPNGval(std::string filename, int offset){
		std::fstream fin( filename.c_str(), std::ios::in);
		unsigned long int tmp, sum;
		long int s;
		int i;
		char r;
		sum = 0;
		fin.seekg(offset, std::ios::beg);
		for(i=0; i<4; i++){
			fin.get(r);
			tmp = pow(256, 4-i-1);
			s = getval(r);
			s = s * tmp;
			sum += s;
		}
		fin.close();
		return sum;
}

void getJPEGsize(std::string  filename, unsigned long int &x, unsigned long int &y){
	std::ifstream fin( filename.c_str(), std::ios::binary);
	int i, marker, code, length, nl, tmp;
	nl = 0; code = 0;
	char r;
	const int MARKER = -1;
	const int size_first = 0xC0;
	const int size_last = 0xC3;
	fin.seekg(2, std::ios::beg);
	int found = 0;
	while( ! found ){
		length = 4;
		for(i=0; i<length; i++){
			fin.get(r);
			tmp = getval(r);
			if(i==0) marker = int(r);
			if(i==1) code = tmp;
			if(i==2) nl = 256*tmp;
			if(i==3) nl+= tmp;
		}

		if( marker!= MARKER ){
			found = 1;
		} else if( ( code>=size_first ) && ( code <=size_last ) ){
				//std::cout << "sizeof(char)=" << sizeof(char) << "\n";
				fin.get(r);
				fin.get(r);
				y = 256*getval(r);
				fin.get(r);
				y += getval(r);
				fin.get(r);
				x = 256*getval(r);
				fin.get(r);
				x += getval(r);
			found = 1;
		} else {
			fin.seekg(nl-2, std::ios::cur);
		}
	}

	fin.close();
}


void GetImageSize(std::string filename, unsigned long int &x, unsigned long int &y){
	if( isPNG(filename) ){
		x = getPNGval(filename, 16);
		y = getPNGval(filename, 20);
	}
	if( isJPEG(filename)){
		getJPEGsize(filename, x, y);
	}
}

/*int main(int argc, char **argv){
  if(argc!=2){
    std::cout << "Please, give file name!\n";
    return 0;
  }

  unsigned long int x,y;
  x=0; y=0;

  GetImageSize(argv[1], x ,y);

  std::cout << "Image type is : ";
  if( isPNG(argv[1]) ) std::cout << "PNG ";
  if( isJPEG(argv[1]) ) std::cout << "JPEG ";
  std::cout << std::endl;

  std::cout << "x=" << x << "; y=" << y <<";\n" ;

  return 0;
}*/
