/* * * * * * * * * * * * * * * * * * * * * * * * * *

Copyright (c) 2008-2009  DeXPeriX a.k.a. Hrabrov Dmitry      http://dexperix.net
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

* * * * * * * * * * * * * * * * * * * * * * * * * */


#ifndef CONCOLOR_H
#define CONCOLOR_H





#define FG_SKIP -1
#define BG_SKIP -2


#if defined(WIN32) //OS

#include <windows.h>

#define FG_BLACK 0
#define FG_RED FOREGROUND_RED
#define FG_GREEN FOREGROUND_GREEN
#define FG_BROWN FOREGROUND_GREEN | FOREGROUND_RED
#define FG_BLUE FOREGROUND_BLUE
#define FG_MAGENTA FOREGROUND_RED | FOREGROUND_BLUE
#define FG_CYAN FOREGROUND_BLUE | FOREGROUND_GREEN
#define FG_WHITE FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_GREEN
#define FG_DEFAULT FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_GREEN

#define BG_BLACK 0
#define BG_RED BACKGROUND_RED
#define BG_GREEN BACKGROUND_GREEN
#define BG_BROWN BACKGROUND_GREEN | BACKGROUND_RED
#define BG_BLUE BACKGROUND_BLUE
#define BG_MAGENTA BACKGROUND_RED | BACKGROUND_BLUE
#define BG_CYAN BACKGROUND_BLUE | BACKGROUND_GREEN
#define BG_WHITE BACKGROUND_BLUE | BACKGROUND_RED | BACKGROUND_GREEN
#define BG_DEFAULT 0
//| BACKGROUND_INTENSITY

#elif defined(__MSDOS__)

#include <conio.h>
#define printf cprintf

#define FG_BLACK 0
#define FG_BLUE 1
#define FG_GREEN 2
#define FG_CYAN 3
#define FG_RED 4
#define FG_MAGENTA 5
#define FG_BROWN 6
#define FG_WHITE 15
#define FG_DEFAULT 15

#define BG_BLACK 0
#define BG_BLUE 1
#define BG_GREEN 2
#define BG_CYAN 3
#define BG_RED 4
#define BG_MAGENTA 5
#define BG_BROWN 6
#define BG_WHITE 7
#define BG_DEFAULT 0

#else //OS

#include <termios.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>

#define FG_BLACK 30
#define FG_RED 31
#define FG_GREEN 32
#define FG_BROWN 33
#define FG_BLUE 34
#define FG_MAGENTA 35
#define FG_CYAN 36
#define FG_WHITE 37
#define FG_DEFAULT 0

#define BG_BLACK 40
#define BG_RED 41
#define BG_GREEN 42
#define BG_BROWN 43
#define BG_BLUE 44
#define BG_MAGENTA 45
#define BG_CYAN 46
#define BG_WHITE 47
#define BG_DEFAULT 0

#endif //OS





typedef struct { 
   int fg_color; 
   int bg_color;
   int intensity;
} dxcolors;


void init_colors(); //Initialization. MUST run first
void set_colors(int fg_color, int bg_color, int intensity); //Set terminal colors and intensivity of foreground color
void set_fg_color(int color, int intensity); //Set only foreground color. Background color is default (transparent)
void restore_def_colors(); //Restore default (before start) parameters

int colprintf ( dxcolors colors, const char * format, ... );

void save_colors(); //Save current color set 
void load_colors(); //Load color set, saved in lastt save_colors function

int congetch(); //Get character

int get_term_height(); //get terminal rows count
int get_console_height(); //alias
int get_term_width();  //get terminal cols count
int get_console_width(); //alias

void move(int x, int y); //move cursor to (x,y)

void clear_screen();
void reset_string(); //Goes to begin of the current string
void app_exit(char * message); //Show message before exit from application. In DOS and Win32 waits for user's responce


#endif //CONCOLOR_H
