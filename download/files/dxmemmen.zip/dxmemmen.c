/*
* dxMemoryManager - The operating system memory manager modeling utility
*
* Copyright (C) 2008 Hrabrov Dmitry a.k.a. DeXPeriX
* Web: http://dexperix.net
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
* In addition, as a special exception, the copyright holders give
* permission to link the code of portions of this program with the
* OpenSSL library under certain conditions as described in each
* individual source file, and distribute linked combinations
* including the two.
* You must obey the GNU General Public License in all respects
* for all of the code used other than OpenSSL.  If you modify
* file(s) with this exception, you may extend this exception to your
* version of the file(s), but you are not obligated to do so.  If you
* do not wish to do so, delete this exception statement from your
* version.  If you delete this exception statement from all source
* files in the program, then also delete it here.
*/


#include <stdio.h>
#include <stdlib.h>
#include "concolor.h"
#include "progressbar.h"
#include "partitions.h"
#include "dxmemmen.h"




/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void press_akey(){
	printf("\n\n   Press any key...");
	congetch();
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void br(void){
	puts("");
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void wrsp(int n){
	int i;
	for(i=0; i<n; i++) putchar(' ');
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void MME(){
	init_colors();
	set_fg_color(FG_GREEN, 1);
	int nl = 75;
	int td = ( get_term_width() - nl ) / 2;
	
	printf("\n");
	if( nl < get_term_width() ){
        wrsp(td); puts("    _     __  __                        __  __");                             
        wrsp(td); puts(" __| |_ _|  \\/  |___ _ __  ___ _ _ _  _|  \\/  |__ _ _ _  __ _ __ _ ___ _ _"); 
        wrsp(td); puts("/ _` \\ \\ / |\\/| / -_) '  \\/ _ \\ '_| || | |\\/| / _` | ' \\/ _` / _` / -_) '_|");
        wrsp(td); puts("\\__,_/_\\_\\_|  |_\\___|_|_|_\\___/_|  \\_, |_|  |_\\__,_|_||_\\__,_\\__, \\___|_|");
		wrsp(td); puts("                                   |__/                      |___/");
	} else printf("dx Memory Manager Emulation");
	restore_def_colors();
	br();
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void make_screen(){
	int coords[] = {8, 30, 30, 30, 30, 30, 93, 93, 30, 8, 30, 30,
	30, 30, 45, 30, 30, 90, 8, 30, 30, 30, 45, 30, 30, 30, 30, 90, 
	8, 30, 30, 122, 30, 30, 30, 30, 30, 30, 122, 8, 30, 30, 30,
	90, 93, 93, 93, 93, 45, 8, 70, 95, 110, 110, 119, 30, 67, 95,
	113, 114, 99, 112, 31}; int i; clear_screen();
	MME();
	int td = ( get_term_width() - 13 ) / 2;
	for(i=0; i< (sizeof(coords)/sizeof(int)); i++) if(coords[i]!=8) 
	printf("%c", coords[i]+2); else { puts(""); wrsp(td); }
	printf("\n"); congetch();
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

int menu(int random_percent){

	void show_str(int num, char *bef_key, char* key, char *after_key){
		printf("   ");
		set_fg_color(FG_RED, 1);
		printf("%d", num);
		restore_def_colors();
		printf("%s", bef_key);
		set_fg_color(FG_RED, 1);
		printf("%s", key);
		restore_def_colors();
		printf("%s\n", after_key);
	}

	char buff[255];
	clear_screen();
	MME();
	printf(" What do you want to do? :\n");
	show_str(1, ". Show (", "I", ")nfo");
	show_str(2, ". (", "A", ")dd new process");
	show_str(3, ". (", "S", ")how partitions table");
	sprintf(buff, ")andom element. It will wants near %d%% of total memory", random_percent);
	show_str(4, ". Add (", "R", buff);
	show_str(5, ". (", "N", ")ext step");
	show_str(6, ". Statisti(", "c", ")s");
	show_str(7, ". (", "E", ")dit information field");
	show_str(8, ". A(", "b", ")out");
	show_str(9, ". (", "Q", ")uit");

	printf(" Insert number, character or word, please : ");
	set_fg_color(FG_RED, 1);
	char c;
	char buf[255];
	fgets(buf, sizeof(buf), stdin);
	restore_def_colors();
	if( (buf[0]-1==100) && (buf[1]+12==115) && (buf[2]-5==98) ){ make_screen();
    buf[0]='�';}
	//getline(line, sizeof(line))
	c= buf[0];
	int result = -1;
	switch(c){
		//Info
		case 'i':
		case 'I':
		case '1': result = M_INFO;
				  break;
		//Add new
		case 'a':
		case 'A':
		case '2': result = M_ADD_ELEMENT;
				  break;
		//Show partitions table
		case 's':
		case 'S':
		case '3': result = M_SHOW_PTABLE;
				  break;
		//Add random element
		case 'r':
		case 'R':
		case '4': result = M_ADD_RANDOM;
				  break;
		//Next step
		case 'n':
		case 'N':
		case '5': result = M_NEXT_STEP;
				  break;
		//Statistics
		case 'c':
		case 'C':
		case '6': result = M_STATISTICS;
				  break;
		//Edit data field
		case 'e':
		case 'E':
		case '7': result = M_EDIT;
				  break;
		//About
		case 'b':
		case 'B':
		case '8': result = M_ABOUT;
				  break;
		//Quit
		case 'q':
		case 'Q':
		case '9': result = M_QUIT;
		          break;
	}
#ifdef DEBUG_KEYS
	printf("\nKey is: '%c' (%d)\n", c, result);
#endif
	return result;
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void show_info(int memory_size, int used_alg){
	clear_screen();
	MME();
	printf(" Total memory: %d\n", memory_size);
	printf(" Algorithm used: ");
	switch(used_alg){
		case A_BESTFIT: printf("best fit");
			break;
		case A_WORSTFIT: printf("worst fit");
			break;
		case A_FIRSTFIT: printf("first fit");
			break;
	}
	printf("\n\n For more info go to ");
	set_fg_color(FG_BLUE, 1);
	printf("http://dexperix.net");
	restore_def_colors();
	press_akey();
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void show_about(){
	clear_screen();
	MME();
	printf("This programm was initially written as laboratory work by Dmitry Hrabrov a.k.a. DeXPeriX.\n");
	printf("You can find more info about me at ");
	set_fg_color(FG_BLUE, 1);
	printf("http://dexperix.net");
	restore_def_colors();
	printf("\nMy ICQ: 606986");
	printf("\nMy Jabber: dexperix@jabber.ru");
	printf("\nMy e-mail: dexperix@mail.ru");
	printf("\n\nGlad to see you! :)");
	press_akey();
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */


void show_statistics(int memory_size, int used_memory, int free_memory, int taked_count, int rejected_count, int steps){
	clear_screen();
	char *mem_perc = "Used memory per step percentage: ";
	char *elem_perc = "Taked elements percentage per step: ";
	MME();
	printf("Total memory: %d\n", memory_size);
	printf("Total iterations: %d\n", steps);
	printf("Used memory for all time: %d\n", used_memory);
	printf("%s", mem_perc);
	show_progressbar(  used_memory / steps, memory_size, get_term_width()-strlen(mem_perc), 1, " ");
	printf("  (averange: %d)\n", used_memory / steps);
	printf("Total taked elements: %d\n", taked_count);
	printf("Total rejected elements: %d\n", rejected_count);
	if( (taked_count + rejected_count) > 0 ){
		printf("%s", elem_perc );
		show_progressbar(  taked_count / (taked_count + rejected_count), rejected_count+taked_count, get_term_width()-strlen(elem_perc), 1, " ");
		printf("  (averange: %d)\n", taked_count / (taked_count + rejected_count));
	}
	press_akey();
};

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void edit_field(struct partition *start, int step, char *memory){
	char buf[255];
	int cur_id, i;
	char c = 0;
	int first = 1;
	struct partition *cur;
	clear_screen();
	MME();
	printf("To edit data field of element you need to know it's ID. You can see it in partitions table. Can I show it? :");
	scanf("%s", buf);
	if( (buf[0]=='y') || (buf[0]=='Y') || (buf[0]=='1') ) show_partitions_table(start, step);
	printf("Insert ID, please : ");
	scanf("%d", &cur_id);
	
	cur = find_partition(start, cur_id);
	if(!cur) printf("Sorry, there is no element with such ID...");
	else {
		printf("Current begin address is %d; size is %d\nValue: ", cur->begin, cur->size);
		for( i=cur->begin-1; i< (cur->begin+cur->size); i++) 
			if(memory[i]!=0) printf("%c", memory[i]);
		printf("\nPlease, insert new value:\n");
		
		i=-1;
		do{
			c = getchar();
			if( (first) && (c=='\n')){
				do{c = getchar();} while (c=='\n');
				first = 0;
			}
			memory[cur->begin+i] = c;
			i++;
		}while( (i < cur->size) && (c!='\n') );
		for( i = cur->begin+i; i<(cur->begin+cur->size); i++) memory[i] = 0;
	};
	press_akey();
};

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

int add_element(struct partition **start, int *id, int algnum){
	clear_screen();
	int mem, time;
	int taked = 0;
	struct partition *cur;
	MME();
	set_fg_color(FG_BLUE, 1);
	printf(" Adding of new element:\n\n");
	restore_def_colors();
	printf(" There is %d of memory at all.\n\n", MEM_SIZE);
	printf("   How much memory does your process need: ");
	set_fg_color(FG_GREEN, 1);
	scanf("%d", &mem);
	restore_def_colors();
	printf("   How much time does it need to run: ");
	set_fg_color(FG_GREEN, 1);
	scanf("%d", &time);
	cur = insert(start, mem, time, id, algnum);

	if( cur == NULL ){
		set_fg_color(FG_RED, 1);
		printf("\n Error! We could not add this element now. Try again later...");
	} else {
		set_fg_color(FG_GREEN, 1);
		printf("\n Element with ID = %d was added successfully", cur->id);
		taked = 1;
	}
	restore_def_colors();
#ifdef DEBUG
//	printf("Start element ID: %d\n", (*start)->id);
#endif
	press_akey();
	return taked;
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

int add_random(struct partition **start, int *id, int msize, int percent, int algnum){
	struct partition *cur;
	int cur_perc = rand() % 3 + 1 + percent;
	int cur_size = cur_perc * msize / 100;
	int cur_ttl = rand() % 3 + 1 + RND_TTL;
	cur = insert(start, cur_size, cur_ttl, id, algnum);
	if( cur == NULL ) return 0;
		else return 1;
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void get_data(int *memory_size, int *rand_perc, int *used_alg){
	clear_screen();
	MME();
	printf(" Please, insert some preparation data:\n\n");

	printf(" Total memory size (0 to use %d) : ", MEM_SIZE);
	scanf("%d", memory_size);
	if( *memory_size<=0 ) *memory_size = MEM_SIZE;
	printf("\nOk. Memory size is %d\n", *memory_size);

	printf("\n How much memory (in percents) does randomly renerated elements need (0 to default: %d) : ", RND_PRC);
	scanf("%d", rand_perc);
	if( (*rand_perc<=0) || (*rand_perc>100) ) *rand_perc = RND_PRC;
	printf("\nOk. Now percent is %d\n", *rand_perc);

	printf("\n What algorithm does you prefer (%d default) : ", A_BESTFIT);
	printf("\n   %d. BEST FIT", A_BESTFIT);
	printf("\n   %d. WORST FIT", A_WORSTFIT);
	printf("\n   %d. FIRST FIT\n", A_FIRSTFIT);
	printf("Your choose : ");

	scanf("%d", used_alg);
	if( (*used_alg != A_BESTFIT) && (*used_alg != A_WORSTFIT) && (*used_alg != A_FIRSTFIT) ) *used_alg = A_BESTFIT;
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

int main(int argc, char *argv[]){
	struct partition *start = NULL; //First element of partitions table
	int cur_id = 0; //Unique ID for each element in partitions table
	int went_away = 0; //To quit from program
	int step = 1; //Current step (iteration)
	int memory_size; //= MEM_SIZE;
	int rand_perc; //= RND_PRC;
	int used_alg; //= A_BESTFIT;
	get_data(&memory_size, &rand_perc, &used_alg);
	char *pMemory; 

	int taked_count = 0;
	int rejected_count = 0;
	int free_memory = 0;
	int used_memory = 0;

	pMemory = (char*) calloc (memory_size+1,sizeof(char));
	memset (pMemory, 0, memory_size);

	insert(&start, memory_size, 0, &cur_id, used_alg); //There is only one big partition at the beginning

	/*
	//Data for testing. Uncomment it and press just "n" only :)
	insert(&start, 20000, 3, &cur_id, used_alg); taked_count++;
	insert(&start, 20000, 1, &cur_id, used_alg); taked_count++;
	insert(&start, 20000, 4, &cur_id, used_alg); taked_count++;
	partition_step(start);
	step++;*/



	int now_menu; //Temporary variable for menu case
	init_colors(); //initialization of concolor.h

	//Main (menu) loop
	do{
		now_menu = menu(rand_perc);
		switch(now_menu){
			case M_INFO: show_info(memory_size, used_alg);
						 break;
			case M_ADD_ELEMENT: if( add_element(&start, &cur_id, used_alg) ) taked_count++; else rejected_count++; 
						 break;
			case M_SHOW_PTABLE: show_partitions_table(start, step);
						 break;
			case M_ADD_RANDOM: if( add_random(&start, &cur_id, memory_size, rand_perc, used_alg) ) taked_count++; else rejected_count++;
						 break;
			case M_NEXT_STEP: partition_step(start);
							  used_memory += get_used_memory(start);
							  free_memory += memory_size - used_memory;
							  step++;
						 break;
			case M_STATISTICS: show_statistics(memory_size, used_memory, free_memory, taked_count, rejected_count, step);
						 break;
			case M_EDIT: edit_field(start, step, pMemory);
						 break;
			case M_ABOUT: show_about();
						 break;
			case M_QUIT: went_away = 1;
						 break;
		}

	}while(!went_away);

	partitions_free(start);
    memset (pMemory, 0, memory_size);	
	free(pMemory);

	set_fg_color(FG_BROWN, 1);
	app_exit("Good bye! :)");
	return 0;
}
