#ifndef PARTITIONS_H
#define PARTITIONS_H
#include <stdlib.h>
#include <stdio.h>
#include "concolor.h"

struct partition{
	int id;
	int size;
	int begin;
	int ttl; //Time To Live
	struct partition *next;
	struct partition *prev;
};

struct partition *insert(struct partition **pstart, int memory, int time, int *id, int algnum);
void show_partitions_table(struct partition *start, int step);
void partition_step(struct partition *start);
struct partition *find_partition(struct partition *start, int cur_id);
int get_used_memory(struct partition *start);
void partitions_free(struct partition *start);
#endif //PARTITIONS_H
